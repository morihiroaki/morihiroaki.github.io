rm(list = ls())
## load.fun(x) will load library 'x' if it is installed. If 'x' has
## not been installed, it will install it. Understanding this code is
## not necessary
## source: http://r.789695.n4.nabble.com/Install-package-automatically-if-not-there-tp2267532p2267659.html
load.fun <- function(x) {
  x <- as.character(substitute(x))
  if(isTRUE(x %in% .packages(all.available=TRUE))) {
    eval(parse(text=paste("require(", x, ")", sep="")))
  } else {
    #update.packages()  ## good idea, but may take some time. can
    ## usually be safely skipped
    eval(parse(text=paste("install.packages('", x, "')", sep="")))
    eval(parse(text=paste("require(", x, ")", sep="")))
  }
}
#################################################################
load.fun(xlsx); load.fun(foreign)
setwd("/Users/mori/Dropbox/Research/KM_WoL/WoL_final/data")
if (!file.exists("lfs_ts.xls")) {
  download.file(url="http://www.stat.go.jp/data/roudou/longtime/zuhyou/lt02.xls",
                destfile="lfs_ts.xls")
}
if (!file.exists("cps_ts.xlsx")) {
  download.file(url="https://www.bls.gov/cps/cpsa2016.xlsx",
                destfile="cps_ts.xlsx")
}

df <- data.frame(matrix(NA, nrow = 17, ncol=3))
ndf <- data.frame(matrix(NA, nrow = 17, ncol=3))
datajp <- read.xlsx("lfs_ts.xls", sheetName="長期02")
df[,1] <- datajp[57:73,2]
df[,2] <- as.numeric(as.character(datajp[57:73,4]))
df[,3] <- as.numeric(as.character(datajp[57:73,6]))
for (i in 1:17){
  ndf[i,1] <- df[i,1]
  ndf[i,2] <- (df[i,3]/df[i,2])*100
}
rm(df, datajp)
df <- data.frame(matrix(NA, nrow = 17, ncol=3))
dataus <- read.xlsx("cps_ts.xlsx", sheetName="cpsaat01")
df[,1] <- dataus[65:81,1]
df[,2] <- as.numeric(as.character(dataus[65:81,3]))
df[,3] <- as.numeric(as.character(dataus[65:81,9]))
for (i in 1:17){
  ndf[i,3] <- (df[i,3]/df[i,2])*100
}
rm(df, dataus)
names(ndf)[names(ndf)=="X1"] <- "year"
names(ndf)[names(ndf)=="X2"] <- "urjp"
names(ndf)[names(ndf)=="X3"] <- "urus"
write.dta(ndf, "cd_a2_fig3.dta")