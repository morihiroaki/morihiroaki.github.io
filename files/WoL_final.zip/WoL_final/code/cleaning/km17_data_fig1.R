rm(list = ls())
## load.fun(x) will load library 'x' if it is installed. If 'x' has
## not been installed, it will install it. Understanding this code is
## not necessary
## source: http://r.789695.n4.nabble.com/Install-package-automatically-if-not-there-tp2267532p2267659.html
load.fun <- function(x) {
  x <- as.character(substitute(x))
  if(isTRUE(x %in% .packages(all.available=TRUE))) {
    eval(parse(text=paste("require(", x, ")", sep="")))
  } else {
    #update.packages()  ## good idea, but may take some time. can
    ## usually be safely skipped
    eval(parse(text=paste("install.packages('", x, "')", sep="")))
    eval(parse(text=paste("require(", x, ")", sep="")))
  }
}
load.fun(xlsx); load.fun(foreign) 

setwd("/Users/mori/Dropbox/Research/KM_WoL/Wol_final/data")
if (!file.exists("lfs_age_pop.xls")) {
  download.file(url="http://www.stat.go.jp/data/roudou/longtime/zuhyou/lt03-01.xls",
                destfile="lfs_age_pop.xls")
}
if (!file.exists("lfs_age_lf.xls")) {
  download.file(url="http://www.stat.go.jp/data/roudou/longtime/zuhyou/lt03-02.xls",
                destfile="lfs_age_lf.xls")
}

ndf <- data.frame(matrix(NA, nrow = 17, ncol=11))
datap <- read.xlsx("lfs_age_pop.xls", sheetName="総数")　
datal <- read.xlsx("lfs_age_lf.xls", sheetName="総数")　
df1 <- data.frame(matrix(NA, nrow = 17, ncol=12))
df2 <- data.frame(matrix(NA, nrow = 17, ncol=12))
for (i in 1:12){
  k=i+2
  df1[,i]      <- as.numeric(as.character(datap[42:58,k]))
  df2[,i]      <- as.numeric(as.character(datal[42:58,k]))
}
tdf <- data.frame(matrix(NA, nrow = 17, ncol=1))
ndf[,1] = as.numeric(as.character(datap[42:58,2]))
tdf[,1] = as.data.frame(rowSums(df1[,2:3]))
ndf[,2] = tdf[,1]
tdf[,1] = as.data.frame(rowSums(df1[,4:9]))
ndf[,3] = tdf[,1]
tdf[,1] = as.data.frame(rowSums(df1[,10:11]))
ndf[,4] = tdf[,1]
ndf[,5] = df1[,12]
ndf[,6] = df1[,1]

tdf[,1] = as.data.frame(rowSums(df2[,2:3]))
ndf[,7] = tdf[,1]
tdf[,1] = as.data.frame(rowSums(df2[,4:9]))
ndf[,8] = tdf[,1]
tdf[,1] = as.data.frame(rowSums(df2[,10:11]))
ndf[,9] = tdf[,1]
ndf[,10] = df2[,12]
ndf[,11] = df2[,1]

rm(df1, df2, tdf, datap, datal)
names(ndf)[names(ndf)=="X1"] <- "year"
names(ndf)[names(ndf)=="X2"] <- "ps1"
names(ndf)[names(ndf)=="X3"] <- "ps2"
names(ndf)[names(ndf)=="X4"] <- "ps3"
names(ndf)[names(ndf)=="X5"] <- "ps4"
names(ndf)[names(ndf)=="X6"] <- "psall"
names(ndf)[names(ndf)=="X7"] <- "lf1"
names(ndf)[names(ndf)=="X8"] <- "lf2"
names(ndf)[names(ndf)=="X9"] <- "lf3"
names(ndf)[names(ndf)=="X10"] <- "lf4"
names(ndf)[names(ndf)=="X11"] <- "lfall"

write.dta(ndf, "cd_fig1.dta")