rm(list = ls())
## load.fun(x) will load library 'x' if it is installed. If 'x' has
## not been installed, it will install it. Understanding this code is
## not necessary
## source: http://r.789695.n4.nabble.com/Install-package-automatically-if-not-there-tp2267532p2267659.html
load.fun <- function(x) {
  x <- as.character(substitute(x))
  if(isTRUE(x %in% .packages(all.available=TRUE))) {
    eval(parse(text=paste("require(", x, ")", sep="")))
  } else {
    #update.packages()  ## good idea, but may take some time. can
    ## usually be safely skipped
    eval(parse(text=paste("install.packages('", x, "')", sep="")))
    eval(parse(text=paste("require(", x, ")", sep="")))
  }
}
load.fun(xlsx); load.fun(foreign) 

setwd("/Users/mori/Dropbox/Research/KM_WoL/WoL_final/data")
if (!file.exists("lfs_mar16.xls")) {
  download.file(url="http://www.e-stat.go.jp/SG1/estat/Xlsdl.do?sinfid=000031532615",
                destfile="lfs_mar16.xls")
}
if (!file.exists("lfs_mar15.xls")) {
  download.file(url="http://www.stat.go.jp/data/roudou/report/2015/ft/zuhyou/b00300.xls",
                destfile="lfs_mar15.xls")
}
if (!file.exists("lfs_mar14.xls")) {
  download.file(url="http://www.stat.go.jp/data/roudou/report/2014/ft/zuhyou/b00300.xls",
                destfile="lfs_mar14.xls")
}
if (!file.exists("lfs_mar13.xls")) {
  download.file(url="http://www.stat.go.jp/data/roudou/report/2013/ft/zuhyou/b00300.xls",
                destfile="lfs_mar13.xls")
}
if (!file.exists("lfs_mar12.xls")) {
  download.file(url="http://www.stat.go.jp/data/roudou/report/2012/ft/zuhyou/a02800.xls",
                destfile="lfs_mar12.xls")
}
if (!file.exists("lfs_mar11.xls")) {
  download.file(url="http://www.stat.go.jp/data/roudou/report/2011/ft/zuhyou/a02800.xls",
                destfile="lfs_mar11.xls")
}
if (!file.exists("lfs_mar10.xls")) {
  download.file(url="http://www.stat.go.jp/data/roudou/report/2010/ft/zuhyou/a02800.xls",
                destfile="lfs_mar10.xls")
}
if (!file.exists("lfs_mar09.xls")) {
  download.file(url="http://www.stat.go.jp/data/roudou/report/2009/zuhyou/ft/a02800.xls",
                destfile="lfs_mar09.xls")
}
if (!file.exists("lfs_mar08.xls")) {
  download.file(url="http://www.stat.go.jp/data/roudou/report/2008/ft/zuhyou/a02800.xls",
                destfile="lfs_mar08.xls")
}
if (!file.exists("lfs_mar07.xls")) {
  download.file(url="http://www.stat.go.jp/data/roudou/report/2007/ft/zuhyou/a02800.xls",
                destfile="lfs_mar07.xls")
}
if (!file.exists("lfs_mar06.xls")) {
  download.file(url="http://www.stat.go.jp/data/roudou/report/2006/ft/zuhyou/a02800.xls",
                destfile="lfs_mar06.xls")
}
if (!file.exists("lfs_mar05.xls")) {
  download.file(url="http://www.stat.go.jp/data/roudou/report/2005/ft/zuhyou/a02800.xls",
                destfile="lfs_mar05.xls")
}
if (!file.exists("lfs_mar04.xls")) {
  download.file(url="https://www.e-stat.go.jp/SG1/estat/GL08020103.do?_xlsDownload_&fileId=000000116083&releaseCount=3",
                destfile="lfs_mar04.xls")
}
if (!file.exists("lfs_mar03.xls")) {
  download.file(url="https://www.e-stat.go.jp/SG1/estat/GL08020103.do?_xlsDownload_&fileId=000000116006&releaseCount=3",
                destfile="lfs_mar03.xls")
}
if (!file.exists("lfs_mar02.xls")) {
  download.file(url="https://www.e-stat.go.jp/SG1/estat/GL08020103.do?_xlsDownload_&fileId=000000115929&releaseCount=3",
                destfile="lfs_mar02.xls")
}
if (!file.exists("lfs_mar01.xls")) {
  download.file(url="https://www.e-stat.go.jp/SG1/estat/GL08020103.do?_xlsDownload_&fileId=000000115853&releaseCount=3",
                destfile="lfs_mar01.xls")
}
if (!file.exists("lfs_mar00.xls")) {
  download.file(url="https://www.e-stat.go.jp/SG1/estat/GL08020103.do?_xlsDownload_&fileId=000000115777&releaseCount=3",
                destfile="lfs_mar00.xls")
}

ndf <- data.frame(matrix(NA, nrow = 17, ncol=4))
names(ndf)[names(ndf)=="X1"] <- "ls"
names(ndf)[names(ndf)=="X2"] <- "lm"
names(ndf)[names(ndf)=="X3"] <- "sp"
names(ndf)[names(ndf)=="X4"] <- "year"

for (k in 16:0){
  if (k==16){
    infile  <- paste("lfs_mar", k, sep="")
    infile1 <- paste(infile, ".xls", sep="")
    datap <- read.xlsx(infile1, sheetName="3")
    df <- data.frame(matrix(NA, nrow = 3, ncol=6))
    for (i in 1:3){
      df[,i]   <- as.numeric(as.character(datap[16:18,i+15]))
      df[,i+3] <- as.numeric(as.character(datap[23:25,i+15]))
    }
    tdf <- as.data.frame(colSums(df))
  }
  if ((k<=15)&&(k>=13)){
    infile  <- paste("lfs_mar", k, sep="")
    infile1 <- paste(infile, ".xls", sep="")
    datap <- read.xlsx(infile1, sheetName="B00300")
    df <- data.frame(matrix(NA, nrow = 6, ncol=6))
    for (i in 1:6){
      df[2,i]  <- as.numeric(as.character(datap[10,30:35][[i]]))
      df[5,i]  <- as.numeric(as.character(datap[11,30:35][[i]]))
      df[1,i]  <- as.numeric(as.character(datap[49,19:24][[i]]))
      df[4,i]  <- as.numeric(as.character(datap[50,19:24][[i]]))
      df[3,i]  <- as.numeric(as.character(datap[49,30:35][[i]]))
      df[6,i]  <- as.numeric(as.character(datap[50,30:35][[i]]))
    }
    tdf <- as.data.frame(rowSums(df))
  }
  if ((k<=12)&&(k>=10)){
    infile  <- paste("lfs_mar", k, sep="")
    infile1 <- paste(infile, ".xls", sep="")
    datap   <- read.xlsx(infile1, sheetName="A02800")
    df <- data.frame(matrix(NA, nrow = 6, ncol=6))
    for (i in 1:6){
      df[2,i]  <- as.numeric(as.character(datap[10,29:34][[i]]))
      df[5,i]  <- as.numeric(as.character(datap[11,29:34][[i]]))
      df[1,i]  <- as.numeric(as.character(datap[40,18:23][[i]]))
      df[4,i]  <- as.numeric(as.character(datap[41,18:23][[i]]))
      df[3,i]  <- as.numeric(as.character(datap[40,29:34][[i]]))
      df[6,i]  <- as.numeric(as.character(datap[41,29:34][[i]]))
    }
    tdf <- as.data.frame(rowSums(df))
  }
  if ((k<=9)&&(k>=5)){
    infile  <- paste("lfs_mar0", k, sep="")
    infile1 <- paste(infile, ".xls", sep="")
    datap   <- read.xlsx(infile1, sheetName="A02800")
    df <- data.frame(matrix(NA, nrow = 6, ncol=6))
    for (i in 1:6){
      df[2,i]  <- as.numeric(as.character(datap[10,29:34][[i]]))
      df[5,i]  <- as.numeric(as.character(datap[11,29:34][[i]]))
      df[1,i]  <- as.numeric(as.character(datap[40,18:23][[i]]))
      df[4,i]  <- as.numeric(as.character(datap[41,18:23][[i]]))
      df[3,i]  <- as.numeric(as.character(datap[40,29:34][[i]]))
      df[6,i]  <- as.numeric(as.character(datap[41,29:34][[i]]))
    }
    tdf <- as.data.frame(rowSums(df))
  }
  if ((k<=4)&&(k>=3)){
    infile  <- paste("lfs_mar0", k, sep="")
    infile1 <- paste(infile, ".xls", sep="")
    datap   <- read.xlsx(infile1, sheetName="200400")
    df <- data.frame(matrix(NA, nrow = 6, ncol=6))
    for (i in 1:6){
      df[1,i]  <- as.numeric(as.character(datap[13,33:38][[i]]))
      df[4,i]  <- as.numeric(as.character(datap[14,33:38][[i]]))
      df[2,i]  <- as.numeric(as.character(datap[13,45:50][[i]]))
      df[5,i]  <- as.numeric(as.character(datap[14,45:50][[i]]))
      df[3,i]  <- as.numeric(as.character(datap[13,57:62][[i]]))
      df[6,i]  <- as.numeric(as.character(datap[14,57:62][[i]]))
    }
    tdf <- as.data.frame(rowSums(df))
  }
  if (k==2){
    infile  <- paste("lfs_mar0", k, sep="")
    infile1 <- paste(infile, ".xls", sep="")
    datap   <- read.xlsx(infile1, sheetName="200400")
    df <- data.frame(matrix(NA, nrow = 6, ncol=6))
    for (i in 1:6){
      df[1,i]  <- as.numeric(as.character(datap[12,25:30][[i]]))
      df[4,i]  <- as.numeric(as.character(datap[13,25:30][[i]]))
      df[2,i]  <- as.numeric(as.character(datap[12,37:42][[i]]))
      df[5,i]  <- as.numeric(as.character(datap[13,37:42][[i]]))
      df[3,i]  <- as.numeric(as.character(datap[12,49:54][[i]]))
      df[6,i]  <- as.numeric(as.character(datap[13,49:54][[i]]))
    }
    tdf <- as.data.frame(rowSums(df))    
  }
  if ((k<=1)&&(k>=0)){
    infile  <- paste("lfs_mar0", k, sep="")
    infile1 <- paste(infile, ".xls", sep="")
    datap   <- read.xlsx(infile1, sheetName="200400")
    df <- data.frame(matrix(NA, nrow = 6, ncol=6))
    for (i in 1:6){
      df[1,i]  <- as.numeric(as.character(datap[12,24:29][[i]]))
      df[4,i]  <- as.numeric(as.character(datap[13,24:29][[i]]))
      df[2,i]  <- as.numeric(as.character(datap[12,35:40][[i]]))
      df[5,i]  <- as.numeric(as.character(datap[13,35:40][[i]]))
      df[3,i]  <- as.numeric(as.character(datap[12,46:51][[i]]))
      df[6,i]  <- as.numeric(as.character(datap[13,46:51][[i]]))
    }
    tdf <- as.data.frame(rowSums(df))
  }  
  ndf[17-k,1] <- (tdf[4,1] + tdf[6,1])/(tdf[1,1] + tdf[3,1]) # LFPR of single 
  ndf[17-k,2] <- tdf[5,1]/tdf[2,1]                           # LFPR of married
  ndf[17-k,3] <- (tdf[1,1] + tdf[3,1])/((tdf[1,1] + tdf[2,1] + tdf[3,1])) # Fraction married in the population
  ndf[17-k,4] <- 2000 + k
  rm(datap, df, tdf)
}
write.dta(ndf, "cd_a2_fig2.dta")