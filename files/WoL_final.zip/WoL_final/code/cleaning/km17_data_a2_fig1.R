## load.fun(x) will load library 'x' if it is installed. If 'x' has
## not been installed, it will install it. Understanding this code is
## not necessary
## source: http://r.789695.n4.nabble.com/Install-package-automatically-if-not-there-tp2267532p2267659.html
load.fun <- function(x) {
  x <- as.character(substitute(x))
  if(isTRUE(x %in% .packages(all.available=TRUE))) {
    eval(parse(text=paste("require(", x, ")", sep="")))
  } else {
    #update.packages()  ## good idea, but may take some time. can
    ## usually be safely skipped
    eval(parse(text=paste("install.packages('", x, "')", sep="")))
    eval(parse(text=paste("require(", x, ")", sep="")))
  }
}
load.fun(xlsx); load.fun(foreign) 
setwd("/Users/mori/Dropbox/Research/KM_WoL/WoL_final/data")
if (!file.exists("lfs_age_pop.xls")) {
  download.file(url="http://www.stat.go.jp/data/roudou/longtime/zuhyou/lt03-01.xls",
                destfile="lfs_age_pop.xls")
}
if (!file.exists("lfs_age_lf.xls")) {
  download.file(url="http://www.stat.go.jp/data/roudou/longtime/zuhyou/lt03-02.xls",
                destfile="lfs_age_lf.xls")
}

ndf <- data.frame(matrix(NA, nrow = 17, ncol=21))

datap <- read.xlsx("lfs_age_pop.xls", sheetName="男")
datal <- read.xlsx("lfs_age_lf.xls", sheetName="男")

df1 <- data.frame(matrix(NA, nrow = 17, ncol=12))
df2 <- data.frame(matrix(NA, nrow = 17, ncol=12))
for (i in 1:12){
  k=i+2
  df1[,i]   <- as.numeric(as.character(datap[42:58,k]))
  df2[,i]   <- as.numeric(as.character(datal[42:58,k]))
}
ndf[,1] = as.numeric(as.character(datal[42:58,2]))
ndf[,2] = as.data.frame(rowSums(df1[,4:9]))
ndf[,3] = as.data.frame(rowSums(df2[,4:9]))
ndf[,4] = as.data.frame(rowSums(df1[,2:3]))
ndf[,5] = as.data.frame(rowSums(df2[,2:3]))
ndf[,6] = as.data.frame(df1[,10])
ndf[,7] = as.data.frame(df2[,10])
ndf[,8] = as.data.frame(df1[,11])
ndf[,9] = as.data.frame(df2[,11])
ndf[,10] = as.data.frame(df1[,12])
ndf[,11] = as.data.frame(df2[,12])

names(ndf)[names(ndf)=="X1"] <- "year"
names(ndf)[names(ndf)=="X2"] <- "pma2"
names(ndf)[names(ndf)=="X3"] <- "lma2"
names(ndf)[names(ndf)=="X4"] <- "pma1"
names(ndf)[names(ndf)=="X5"] <- "lma1"
names(ndf)[names(ndf)=="X6"] <- "pma3"
names(ndf)[names(ndf)=="X7"] <- "lma3"
names(ndf)[names(ndf)=="X8"] <- "pma4"
names(ndf)[names(ndf)=="X9"] <- "lma4"
names(ndf)[names(ndf)=="X10"] <- "pma5"
names(ndf)[names(ndf)=="X11"] <- "lma5"


rm(df1,df2, datal, datap)

datap <- read.xlsx("lfs_age_pop.xls", sheetName="女")
datal <- read.xlsx("lfs_age_lf.xls", sheetName="女")

df1 <- data.frame(matrix(NA, nrow = 17, ncol=12))
df2 <- data.frame(matrix(NA, nrow = 17, ncol=12))
for (i in 1:12){
  k=i+2
  df1[,i]   <- as.numeric(as.character(datap[42:58,k]))
  df2[,i]   <- as.numeric(as.character(datal[42:58,k]))
}
ndf[,12] = as.data.frame(rowSums(df1[,4:9]))
ndf[,13] = as.data.frame(rowSums(df2[,4:9]))
ndf[,14] = as.data.frame(rowSums(df1[,2:3]))
ndf[,15] = as.data.frame(rowSums(df2[,2:3]))
ndf[,16] = as.data.frame(df1[,10])
ndf[,17] = as.data.frame(df2[,10])
ndf[,18] = as.data.frame(df1[,11])
ndf[,19] = as.data.frame(df2[,11])
ndf[,20] = as.data.frame(df1[,12])
ndf[,21] = as.data.frame(df2[,12])

names(ndf)[names(ndf)=="X12"] <- "pwa2"
names(ndf)[names(ndf)=="X13"] <- "lwa2"
names(ndf)[names(ndf)=="X14"] <- "pwa1"
names(ndf)[names(ndf)=="X15"] <- "lwa1"
names(ndf)[names(ndf)=="X16"] <- "pwa3"
names(ndf)[names(ndf)=="X17"] <- "lwa3"
names(ndf)[names(ndf)=="X18"] <- "pwa4"
names(ndf)[names(ndf)=="X19"] <- "lwa4"
names(ndf)[names(ndf)=="X20"] <- "pwa5"
names(ndf)[names(ndf)=="X21"] <- "lwa5"

rm(df1, df2, datal, datap)
write.dta(ndf, "cd_a2_fig1.dta")