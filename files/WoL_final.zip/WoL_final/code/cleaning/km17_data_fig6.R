## load.fun(x) will load library 'x' if it is installed. If 'x' has
## not been installed, it will install it. Understanding this code is
## not necessary
## source: http://r.789695.n4.nabble.com/Install-package-automatically-if-not-there-tp2267532p2267659.html
load.fun <- function(x) {
  x <- as.character(substitute(x))
  if(isTRUE(x %in% .packages(all.available=TRUE))) {
    eval(parse(text=paste("require(", x, ")", sep="")))
  } else {
    #update.packages()  ## good idea, but may take some time. can
    ## usually be safely skipped
    eval(parse(text=paste("install.packages('", x, "')", sep="")))
    eval(parse(text=paste("require(", x, ")", sep="")))
  }
}
########################
load.fun(xlsx); load.fun(foreign); load.fun(stats) 


## Download datasets
setwd("/Users/mori/Dropbox/Research/KM_WoL/WoL_final/data/")
# BSWS 2016(h28) Regular Workers: Table 1
if (!file.exists("bsws_h28ft.xls")) {
  download.file(url="http://www.e-stat.go.jp/SG1/estat/Xlsdl.do?sinfid=000031226663",
                destfile="bsws_h28ft.xls")
}
# BSWS 2016(h28) Part-time Workers: Table 1
if (!file.exists("bsws_h28pt.xls")) {
  download.file(url="http://www.e-stat.go.jp/SG1/estat/Xlsdl.do?sinfid=000031228997",
                destfile="bsws_h28pt.xls")
}
if (!file.exists("bsws_h27ft.xls")) {
  download.file(url="http://www.e-stat.go.jp/SG1/estat/Xlsdl.do?sinfid=000028996409",
                destfile="bsws_h27ft.xls")
}
if (!file.exists("bsws_h27pt.xls")) {
  download.file(url="http://www.e-stat.go.jp/SG1/estat/Xlsdl.do?sinfid=000029008193",
                destfile="bsws_h27pt.xls")
}  
if (!file.exists("bsws_h26ft.xls")) {
  download.file(url="http://www.e-stat.go.jp/SG1/estat/Xlsdl.do?sinfid=000026308307",
                destfile="bsws_h26ft.xls")
}
if (!file.exists("bsws_h26pt.xls")) {
  download.file(url="http://www.e-stat.go.jp/SG1/estat/Xlsdl.do?sinfid=000026308750",
                destfile="bsws_h26pt.xls")
}
if (!file.exists("bsws_h25ft.xls")) {
  download.file(url="http://www.e-stat.go.jp/SG1/estat/Xlsdl.do?sinfid=000023602360",
                destfile="bsws_h25ft.xls")
}
if (!file.exists("bsws_h25pt.xls")) {
  download.file(url="http://www.e-stat.go.jp/SG1/estat/Xlsdl.do?sinfid=000023602761",
                destfile="bsws_h25pt.xls")
}
if (!file.exists("bsws_h24ft.xls")) {
  download.file(url="http://www.e-stat.go.jp/SG1/estat/Xlsdl.do?sinfid=000015981178",
                destfile="bsws_h24ft.xls")
}
if (!file.exists("bsws_h24pt.xls")) {
  download.file(url="http://www.e-stat.go.jp/SG1/estat/Xlsdl.do?sinfid=000016356610",
                destfile="bsws_h24pt.xls")
}
if (!file.exists("bsws_h23ft.xls")) {
  download.file(url="http://www.e-stat.go.jp/SG1/estat/Xlsdl.do?sinfid=000012740223",
                destfile="bsws_h23ft.xls")
}
if (!file.exists("bsws_h23pt.xls")) {
  download.file(url="http://www.e-stat.go.jp/SG1/estat/Xlsdl.do?sinfid=000012738575",
                destfile="bsws_h23pt.xls")
}
if (!file.exists("bsws_h22ft.xls")) {
  download.file(url="http://www.e-stat.go.jp/SG1/estat/Xlsdl.do?sinfid=000008278863",
                destfile="bsws_h22ft.xls")
}
if (!file.exists("bsws_h22pt.xls")) {
  download.file(url="http://www.e-stat.go.jp/SG1/estat/Xlsdl.do?sinfid=000008278750",
                destfile="bsws_h22pt.xls")
}
if (!file.exists("bsws_h21ft.xls")) {
  download.file(url="http://www.e-stat.go.jp/SG1/estat/Xlsdl.do?sinfid=000007214289",
                destfile="bsws_h21ft.xls")
}
if (!file.exists("bsws_h21pt.xls")) {
  download.file(url="http://www.e-stat.go.jp/SG1/estat/Xlsdl.do?sinfid=000007215233",
                destfile="bsws_h21pt.xls")
}
if (!file.exists("bsws_h20ft.xls")) {
  download.file(url="http://www.e-stat.go.jp/SG1/estat/Xlsdl.do?sinfid=000002950069",
                destfile="bsws_h20ft.xls")
}
if (!file.exists("bsws_h20pt.xls")) {
  download.file(url="http://www.e-stat.go.jp/SG1/estat/Xlsdl.do?sinfid=000002951148",
                destfile="bsws_h20pt.xls")
}
if (!file.exists("bsws_h19ft.xls")) {
  download.file(url="http://www.e-stat.go.jp/SG1/estat/Xlsdl.do?sinfid=000001254445",
                destfile="bsws_h19ft.xls")
}
if (!file.exists("bsws_h19pt.xls")) {
  download.file(url="http://www.e-stat.go.jp/SG1/estat/Xlsdl.do?sinfid=000001254547",
                destfile="bsws_h19pt.xls")
}
if (!file.exists("bsws_h18ft.xls")) {
  download.file(url="http://www.e-stat.go.jp/SG1/estat/Xlsdl.do?sinfid=000001183263",
                destfile="bsws_h18ft.xls")
}
if (!file.exists("bsws_h18pt.xls")) {
  download.file(url="http://www.e-stat.go.jp/SG1/estat/Xlsdl.do?sinfid=000001183377",
                destfile="bsws_h18pt.xls")
}
if (!file.exists("bsws_h17ft.xls")) {
  download.file(url="http://www.e-stat.go.jp/SG1/estat/Xlsdl.do?sinfid=000001256328",
                destfile="bsws_h17ft.xls")
}
if (!file.exists("bsws_h17pt.xls")) {
  download.file(url="http://www.e-stat.go.jp/SG1/estat/Xlsdl.do?sinfid=000001256435",
                destfile="bsws_h17pt.xls")
}
if (!file.exists("bsws_h16ft.xls")) {
  download.file(url="http://www.e-stat.go.jp/SG1/estat/Xlsdl.do?sinfid=000001256494",
                destfile="bsws_h16ft.xls")
}
if (!file.exists("bsws_h16pt.xls")) {
  download.file(url="http://www.e-stat.go.jp/SG1/estat/Xlsdl.do?sinfid=000001256601",
                destfile="bsws_h16pt.xls")
}
if (!file.exists("bsws_h15ft.xls")) {
  download.file(url="http://www.e-stat.go.jp/SG1/estat/Xlsdl.do?sinfid=000001256639",
                destfile="bsws_h15ft.xls")
}
if (!file.exists("bsws_h15pt.xls")) {
  download.file(url="http://www.e-stat.go.jp/SG1/estat/Xlsdl.do?sinfid=000001256722",
                destfile="bsws_h15pt.xls")
}
if (!file.exists("bsws_h14ft.xls")) {
  download.file(url="http://www.e-stat.go.jp/SG1/estat/Xlsdl.do?sinfid=000001256761",
                destfile="bsws_h14ft.xls")
}
if (!file.exists("bsws_h14pt.xls")) {
  download.file(url="http://www.e-stat.go.jp/SG1/estat/Xlsdl.do?sinfid=000001256844",
                destfile="bsws_h14pt.xls")
}
if (!file.exists("bsws_h13ft.xls")) {
  download.file(url="http://www.e-stat.go.jp/SG1/estat/Xlsdl.do?sinfid=000001256881",
                destfile="bsws_h13ft.xls")
}
if (!file.exists("bsws_h13pt.xls")) {
  download.file(url="http://www.e-stat.go.jp/SG1/estat/Xlsdl.do?sinfid=000001256963",
                destfile="bsws_h13pt.xls")
}
if (!file.exists("bsws_h12ft.xls")) {
  download.file(url="http://www.e-stat.go.jp/SG1/estat/Xlsdl.do?sinfid=000001256993",
                destfile="bsws_h12ft.xls")
}
if (!file.exists("bsws_h12ptm.xls")) {
  download.file(url="http://www.e-stat.go.jp/SG1/estat/Xlsdl.do?sinfid=000001257012",
                destfile="bsws_h12ptm.xls")
}
if (!file.exists("bsws_h12ptw.xls")) {
  download.file(url="http://www.e-stat.go.jp/SG1/estat/Xlsdl.do?sinfid=000001257013",
                destfile="bsws_h12ptw.xls")
}
## Read the datasets into a dataframe
sdfm <- data.frame(matrix(NA, nrow = 17, ncol=53))
sdfw <- data.frame(matrix(NA, nrow = 17, ncol=53))
for (j in 28:12){
  infile  <- paste("bsws_h", j, sep="")
  infile1 <- paste(infile, "ft.xls", sep="")
  infile2 <- paste(infile, "pt.xls", sep="")
  if ((j<=28) && (j>=22)){
    dataf <- read.xlsx(infile1, sheetName="産業計")
    datap <- read.xlsx(infile2, sheetName="産業計～Ｒサービス業(他に分類されないもの)")
    dfm <- dataf[78:90,12:17]
    dfw <- dataf[143:155,12:17]
    dpm <- datap[24:36,13:17]
    dpw <- datap[37:49,13:17]
  }
  if (j==21){
    dataf <- read.xlsx(infile1, sheetName="T　産業計")
    datap <- read.xlsx(infile2, sheetName="産業計～ R サービス業")
    dfm <- dataf[78:90,12:17]
    dfw <- dataf[143:155,12:17]
    dpm <- datap[24:36,13:17]
    dpw <- datap[37:49,13:17]
  }
  if (j==20){
    dataf <- read.xlsx(infile1, sheetName="産業計")
    datap <- read.xlsx(infile2, sheetName="産業計～Ｑサービス業")
    dfm <- dataf[75:87,7:12]
    dfw <- dataf[141:153,7:12]
    dpm <- datap[21:33,6:10]
    dpw <- datap[34:46,6:10]
  }
  if (j==19){
    dataf <- read.xlsx(infile1, sheetName="産業計")
    datap <- read.xlsx(infile2, sheetName="産業計～Ｑサービス業")
    dfm <- dataf[75:87,7:12]
    dfw <- dataf[141:153,7:12]
    dpm <- datap[22:34,6:10]
    dpw <- datap[36:48,6:10]
  }
  if ((j>=17)&&(j<=18)){
    dataf <- read.xlsx(infile1, sheetName="産業計")
    datap <- read.xlsx(infile2, sheetName="産業計～Ｑサービス業")
    dfm <- dataf[22:34,7:12]
    dfw <- dataf[88:100,7:12]
    dpm <- datap[22:34,6:10]
    dpw <- datap[36:48,6:10]
  }
  if (j==16){
    dataf <- read.xlsx(infile1, sheetName="産業計")
    datap <- read.xlsx(infile2, sheetName="産業計､F製造業､J卸売･小売業､K金融･保険業")
    dfm <- dataf[24:36,4:9]
    dfw <- dataf[95:107,4:9]
    dpm <- datap[23:35,4:8]
    dpw <- datap[37:49,4:8]
  }
  if ( (j>=13) && (j<=15)){
    dataf <- read.xlsx(infile1, sheetName="産業計")
    datap <- read.xlsx(infile2, sheetName="産業計､F製造､I卸売小売､飲食店､J金融保険､Lｻｰﾋﾞｽ業")
    dfm <- dataf[24:36,4:9]
    dfw <- dataf[95:107,4:9]
    dpm <- datap[80:92,4:8]
    dpw <- datap[151:163,4:8]
  }
  if (j==12){
    dataf <- read.xlsx("bsws_h12ft.xls", sheetName="産業計")
    datapm <- read.xlsx("bsws_h12ptm.xls", sheetName="男性労働者")
    datapw <- read.xlsx("bsws_h12ptw.xls", sheetName="女性労働者")
    dfm <- dataf[24:36,4:9]
    dfw <- dataf[95:107,4:9]
    dpm <- datapm[9:21,4:8]
    dpw <- datapw[9:21,4:8]
  }
  df  <- data.frame(matrix(NA, nrow = 13, ncol=6))
  df1 <- data.frame(matrix(NA, nrow = 13, ncol=6))
  df2 <- data.frame(matrix(NA, nrow = 13, ncol=6))
  for (i in 1:6){
    df[,i] = as.character(dfm[,i])
    df[,i] = gsub(" ", "", df[,i]) 
    df1[,i] = as.numeric(df[,i])
    df[,i] = as.character(dfw[,i])
    df[,i] = gsub(" ", "", df[,i])   
    df2[,i] = as.numeric(df[,i])
  }
  df  <- data.frame(matrix(NA, nrow = 13, ncol=5))
  df3 <- data.frame(matrix(NA, nrow = 13, ncol=5))
  df4 <- data.frame(matrix(NA, nrow = 13, ncol=5))
  for (i in 1:5){
    df[,i] = as.character(dpm[,i])
    df[,i] = gsub(" ", "", df[,i]) 
    df3[,i] = as.numeric(df[,i])
    df[,i] = as.character(dpw[,i])
    df[,i] = gsub(" ", "", df[,i])   
    df4[,i] = as.numeric(df[,i])
  }
  rm(df, dataf, datap, datapm, datapw, dfm, dfw, dpm, dpw)
  ndf1 <- data.frame(matrix(NA, nrow = 13, ncol=6))
  ndf2 <- data.frame(matrix(NA, nrow = 13, ncol=6))
  ndf3 <- data.frame(matrix(NA, nrow = 13, ncol=6))
  ndf4 <- data.frame(matrix(NA, nrow = 13, ncol=6))
  ndf1[1:13,1] <- (df1[1:13,3] + df1[1:13,5]/12)*10   # monthly earnings for full-time men
  ndf2[1:13,1] <- (df2[1:13,3] + df2[1:13,5]/12)*10   # monthly earnings for full-time women
  ndf1[1:13,2] <- df1[1:13,1] + df1[1:13,2]    # monthly hours for full-time men
  ndf2[1:13,2] <- df2[1:13,1] + df2[1:13,2]    # monthly hours for full-time women
  ndf1[1:13,3] <- ndf1[1:13,1]/ndf1[1:13,2]    # hourly wages for men
  ndf2[1:13,3] <- ndf2[1:13,1]/ndf2[1:13,2]     # hourly wages for women
  ndf1[1:13,4] <- df1[1:13,6]    # size for full-time men
  ndf2[1:13,4] <- df2[1:13,6]    # size for full-time women
  ndf3[1:13,1] <- (df3[1:13,1]*df3[1:13,2])*12   # annual hours for part-time men
  ndf4[1:13,1] <- (df4[1:13,1]*df4[1:13,2])*12   # annual hours for part-time women
  ndf3[1:13,2] <- (df3[1:13,4]/ndf3[1:13,1])*10   # hourly bonus for part-time men
  ndf4[1:13,2] <- (df4[1:13,4]/ndf4[1:13,1])*10   # hourly bonus for part-time women
  ndf3[1:13,3] <- df3[1:13,3]/100 + ndf3[1:13,2]    # hourly wages for part-time men
  ndf4[1:13,3] <- df4[1:13,3]/100 + ndf4[1:13,2]    # hourly wages for part-time women
  ndf3[1:13,4] <- df3[1:13,5]    # size for part-time men
  ndf4[1:13,4] <- df4[1:13,5]    # size for part-time women
  rm(df1,df2,df3,df4)
  l = 29-j
  for (k in 1:13){
    sdfm[l,k]    <- ndf1[k,3]
    sdfm[l,k+13]  <- ndf1[k,4]
    sdfm[l,k+26] <- ndf3[k,3]
    sdfm[l,k+39] <- ndf3[k,4]
    sdfw[l,k]    <- ndf2[k,3]
    sdfw[l,k+13]  <- ndf2[k,4]
    sdfw[l,k+26] <- ndf4[k,3]
    sdfw[l,k+39] <- ndf4[k,4]
  }
  sdfm[l,53] <- 1988+j
  sdfw[l,53] <- 1988+j
  rm(ndf1,ndf2, ndf3, ndf4)
  print(1988+j)
}

for (l in 1:13){
  n1  <- paste("X", l, sep="")
  n2  <- paste("fw_a", l, sep="")
  n3  <- paste("X", l+13, sep="")
  n4  <- paste("fs_a", l, sep="")
  n5  <- paste("X", l+26, sep="")
  n6  <- paste("pw_a", l, sep="")
  n7  <- paste("X", l+39, sep="")
  n8  <- paste("ps_a", l, sep="")
  names(sdfm)[names(sdfm)==n1] <- n2
  names(sdfm)[names(sdfm)==n3] <- n4
  names(sdfm)[names(sdfm)==n5] <- n6
  names(sdfm)[names(sdfm)==n7] <- n8
  names(sdfw)[names(sdfw)==n1] <- n2
  names(sdfw)[names(sdfw)==n3] <- n4
  names(sdfw)[names(sdfw)==n5] <- n6
  names(sdfw)[names(sdfw)==n7] <- n8
}

for (l in 1:13){
  n1  <- paste("X", l, sep="")
  n2  <- paste("fw_a", l, sep="")
  n3  <- paste("X", l+13, sep="")
  n4  <- paste("fs_a", l, sep="")
  n5  <- paste("X", l+26, sep="")
  n6  <- paste("pw_a", l, sep="")
  n7  <- paste("X", l+39, sep="")
  n8  <- paste("ps_a", l, sep="")
  names(sdfm)[names(sdfm)==n1] <- n2
  names(sdfm)[names(sdfm)==n3] <- n4
  names(sdfm)[names(sdfm)==n5] <- n6
  names(sdfm)[names(sdfm)==n7] <- n8
  names(sdfw)[names(sdfw)==n1] <- n2
  names(sdfw)[names(sdfw)==n3] <- n4
  names(sdfw)[names(sdfw)==n5] <- n6
  names(sdfw)[names(sdfw)==n7] <- n8
}
names(sdfm)[names(sdfm)=="X53"] <- "year"
names(sdfw)[names(sdfw)=="X53"] <- "year"
sdfm <- sdfm[order(sdfm$year), ]
sdfw <- sdfw[order(sdfw$year), ]
write.dta(sdfm, "cd_fig6_men.dta")
write.dta(sdfw, "cd_fig6_women.dta")