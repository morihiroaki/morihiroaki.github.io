Kawaguchi and Mori (2017) The Labor Market in Japan, IZA WoL

Instructions for replication:

There are multiple types of files: *.do are STATA do-files and *.R are R script files.
We use R script files to download and clean raw data files. We use stata do-files to produce figures in the paper.

Both the stata do-files and R script files specify the names of the corresponding figures used in the paper. Files with a name that includes "aX" are used in online appendices (not for publication, but available upon request).

