rm(list = ls())
## load.fun(x) will load library 'x' if it is installed. If 'x' has
## not been installed, it will install it. Understanding this code is
## not necessary
## source: http://r.789695.n4.nabble.com/Install-package-automatically-if-not-there-tp2267532p2267659.html
load.fun <- function(x) {
  x <- as.character(substitute(x))
  if(isTRUE(x %in% .packages(all.available=TRUE))) {
    eval(parse(text=paste("require(", x, ")", sep="")))
  } else {
    #update.packages()  ## good idea, but may take some time. can
    ## usually be safely skipped
    eval(parse(text=paste("install.packages('", x, "')", sep="")))
    eval(parse(text=paste("require(", x, ")", sep="")))
  }
}
load.fun(xlsx); load.fun(foreign)
setwd("/Users/mori/Dropbox/Research/KM_WoL/WoL_final/data")
if (!file.exists("bsws_h28ftq.xls")) {
  download.file(url="http://www.e-stat.go.jp/SG1/estat/Xlsdl.do?sinfid=000031226696",
                destfile="bsws_h28ftq.xls")
}
if (!file.exists("bsws_h27ftq.xls")) {
  download.file(url="http://www.e-stat.go.jp/SG1/estat/Xlsdl.do?sinfid=000028996562",
                destfile="bsws_h27ftq.xls")
}
if (!file.exists("bsws_h26ftq.xls")) {
  download.file(url="http://www.e-stat.go.jp/SG1/estat/Xlsdl.do?sinfid=000026308380",
                destfile="bsws_h26ftq.xls")
}
if (!file.exists("bsws_h25ftq.xls")) {
  download.file(url="http://www.e-stat.go.jp/SG1/estat/Xlsdl.do?sinfid=000023602593",
                destfile="bsws_h25ftq.xls")
}
if (!file.exists("bsws_h24ftq.xls")) {
  download.file(url="http://www.e-stat.go.jp/SG1/estat/Xlsdl.do?sinfid=000015981191",
                destfile="bsws_h24ftq.xls")
}
if (!file.exists("bsws_h23ftq.xls")) {
  download.file(url="http://www.e-stat.go.jp/SG1/estat/Xlsdl.do?sinfid=000012740236",
                destfile="bsws_h23ftq.xls")
}
if (!file.exists("bsws_h22ftq.xls")) {
  download.file(url="http://www.e-stat.go.jp/SG1/estat/Xlsdl.do?sinfid=000008278973",
                destfile="bsws_h22ftq.xls")
}
if (!file.exists("bsws_h21ftq.xls")) {
  download.file(url="http://www.e-stat.go.jp/SG1/estat/Xlsdl.do?sinfid=000007361098",
                destfile="bsws_h21ftq.xls")
}
if (!file.exists("bsws_h20ftq.xls")) {
  download.file(url="http://www.e-stat.go.jp/SG1/estat/Xlsdl.do?sinfid=000002950075",
                destfile="bsws_h20ftq.xls")
}
if (!file.exists("bsws_h19ftq.xls")) {
  download.file(url="http://www.e-stat.go.jp/SG1/estat/Xlsdl.do?sinfid=000001254466",
                destfile="bsws_h19ftq.xls")
}

if (!file.exists("bsws_h18ftq.xls")) {
  download.file(url="http://www.e-stat.go.jp/SG1/estat/Xlsdl.do?sinfid=000001183284",
                destfile="bsws_h18ftq.xls")
}
if (!file.exists("bsws_h17ftq.xls")) {
  download.file(url="http://www.e-stat.go.jp/SG1/estat/Xlsdl.do?sinfid=000001256349",
                destfile="bsws_h17ftq.xls")
}

if (!file.exists("bsws_h16ftq.xls")) {
  download.file(url="http://www.e-stat.go.jp/SG1/estat/Xlsdl.do?sinfid=000001256515",
                destfile="bsws_h16ftq.xls")
}
if (!file.exists("bsws_h15ftq.xls")) {
  download.file(url="http://www.e-stat.go.jp/SG1/estat/Xlsdl.do?sinfid=000001256655",
                destfile="bsws_h15ftq.xls")
}
if (!file.exists("bsws_h14ftq.xls")) {
  download.file(url="http://www.e-stat.go.jp/SG1/estat/Xlsdl.do?sinfid=000001256777",
                destfile="bsws_h14ftq.xls")
}
if (!file.exists("bsws_h13ftq.xls")) {
  download.file(url="http://www.e-stat.go.jp/SG1/estat/Xlsdl.do?sinfid=000001256897",
                destfile="bsws_h13ftq.xls")
}
ndf <- data.frame(year=double(),
                  gender=double(),
                  size=double(),
                  q10=double(),
                  q50=double(),
                  q90=double(),
                  r9010=double(),
                  r9050=double(),
                  r5010=double(),
                  stringsAsFactors=FALSE)
df <- data.frame(matrix(NA, nrow = 385, ncol=8))
data28 <- read.xlsx("bsws_h28ftq.xls", sheetName="産業計(規模計)")
data27 <- read.xlsx("bsws_h27ftq.xls", sheetName="産業計(規模計)")
data26 <- read.xlsx("bsws_h26ftq.xls", sheetName="産業計(規模計)")
data25 <- read.xlsx("bsws_h25ftq.xls", sheetName="産業計(規模計)")
data24 <- read.xlsx("bsws_h24ftq.xls", sheetName="産業計(規模計)")
data23 <- read.xlsx("bsws_h23ftq.xls", sheetName="産業計(規模計)")
data22 <- read.xlsx("bsws_h22ftq.xls", sheetName="産業計(規模計)")
data21 <- read.xlsx("bsws_h21ftq.xls", sheetName="産業計（企業規模計）")
df[,1] <- data28$X1
df[,2] <- data27$X1
df[,3] <- data26$X1
df[,4] <- data25$X1
df[,5] <- data24$X1
df[,6] <- data23$X1
df[,7] <- data22$X1
df[,8] <- data21$X1
rm(data28, data27, data26, data25, data24, data23, data22, data21)

for (i in 1:8){
  k = i
  ndf[k,1] <- 2017-i
  ndf[k,2] <- 0
  ndf[k,3] <- as.numeric(as.character(df[11,i]))
  ndf[k,4] <- as.numeric(as.character(df[38,i]))
  ndf[k,5] <- as.numeric(as.character(df[40,i]))
  ndf[k,6] <- as.numeric(as.character(df[42,i]))
  k = i + 8
  ndf[k,1] <- 2017-i
  ndf[k,2] <- 1
  ndf[k,3] <- as.numeric(as.character(df[45,i]))
  ndf[k,4] <- as.numeric(as.character(df[72,i]))
  ndf[k,5] <- as.numeric(as.character(df[74,i]))
  ndf[k,6] <- as.numeric(as.character(df[76,i]))
  k = i + 8 + 8
  ndf[k,1] <- 2017-i
  ndf[k,2] <- 2
  ndf[k,3] <- as.numeric(as.character(df[215,i]))
  ndf[k,4] <- as.numeric(as.character(df[242,i]))
  ndf[k,5] <- as.numeric(as.character(df[244,i]))
  ndf[k,6] <- as.numeric(as.character(df[246,i]))
}
df <- data.frame(matrix(NA, nrow = 1779, ncol=2))
data20 <- read.xlsx("bsws_h20ftq.xls", sheetName="産業計")
data19 <- read.xlsx("bsws_h19ftq.xls", sheetName="産業計")
df[,1] <- data20[,5]
df[,2] <- data19[,5]
rm(data19, data20)
for (i in 1:2){
  k = i + 24
  ndf[k,1] <- 2009-i
  ndf[k,2] <- 0
  ndf[k,3] <- as.numeric(as.character(df[9,i]))
  ndf[k,4] <- as.numeric(as.character(df[40,i]))
  ndf[k,5] <- as.numeric(as.character(df[42,i]))
  ndf[k,6] <- as.numeric(as.character(df[44,i]))
  k = i + 24 + 2
  ndf[k,1] <- 2009-i
  ndf[k,2] <- 1
  ndf[k,3] <- as.numeric(as.character(df[50,i]))
  ndf[k,4] <- as.numeric(as.character(df[81,i]))
  ndf[k,5] <- as.numeric(as.character(df[83,i]))
  ndf[k,6] <- as.numeric(as.character(df[85,i]))
  k = i + 24 + 2 + 2
  ndf[k,1] <- 2009-i
  ndf[k,2] <- 2
  ndf[k,3] <- as.numeric(as.character(df[251,i]))
  ndf[k,4] <- as.numeric(as.character(df[282,i]))
  ndf[k,5] <- as.numeric(as.character(df[284,i]))
  ndf[k,6] <- as.numeric(as.character(df[286,i]))
}
rm(df)

data18 <- read.xlsx("bsws_h18ftq.xls", sheetName="産業計")
df <- data.frame(matrix(NA, nrow = 2093, ncol=1))
df[,1] <- data18[,5]
rm(data18)
for (i in 1:1){
  k = i + 30
  ndf[k,1] <- 2007-i
  ndf[k,2] <- 0
  ndf[k,3] <- as.numeric(as.character(df[9,i]))
  ndf[k,4] <- as.numeric(as.character(df[40,i]))
  ndf[k,5] <- as.numeric(as.character(df[42,i]))
  ndf[k,6] <- as.numeric(as.character(df[44,i]))
  k = i + 30 + 1
  ndf[k,1] <- 2007-i
  ndf[k,2] <- 1
  ndf[k,3] <- as.numeric(as.character(df[50,i]))
  ndf[k,4] <- as.numeric(as.character(df[81,i]))
  ndf[k,5] <- as.numeric(as.character(df[83,i]))
  ndf[k,6] <- as.numeric(as.character(df[85,i]))
  k = i + 30 + 1 + 1
  ndf[k,1] <- 2007-i
  ndf[k,2] <- 2
  ndf[k,3] <- as.numeric(as.character(df[251,i]))
  ndf[k,4] <- as.numeric(as.character(df[282,i]))
  ndf[k,5] <- as.numeric(as.character(df[284,i]))
  ndf[k,6] <- as.numeric(as.character(df[286,i]))
}
rm(df)

data17 <- read.xlsx("bsws_h17ftq.xls", sheetName="産業計")
df <- data.frame(matrix(NA, nrow = 1811, ncol=1))
df[,1] <- data17[,5]
rm(data17)
for (i in 1:1){
  k = i + 33
  ndf[k,1] <- 2006-i
  ndf[k,2] <- 0
  ndf[k,3] <- as.numeric(as.character(df[9,i]))
  ndf[k,4] <- as.numeric(as.character(df[40,i]))
  ndf[k,5] <- as.numeric(as.character(df[42,i]))
  ndf[k,6] <- as.numeric(as.character(df[44,i]))
  k = i + 33 + 1
  ndf[k,1] <- 2006-i
  ndf[k,2] <- 1
  ndf[k,3] <- as.numeric(as.character(df[50,i]))
  ndf[k,4] <- as.numeric(as.character(df[81,i]))
  ndf[k,5] <- as.numeric(as.character(df[83,i]))
  ndf[k,6] <- as.numeric(as.character(df[85,i]))
  k = i + 33 + 1 + 1
  ndf[k,1] <- 2006-i
  ndf[k,2] <- 2
  ndf[k,3] <- as.numeric(as.character(df[251,i]))
  ndf[k,4] <- as.numeric(as.character(df[282,i]))
  ndf[k,5] <- as.numeric(as.character(df[284,i]))
  ndf[k,6] <- as.numeric(as.character(df[286,i]))
}
rm(df)
data16 <- read.xlsx("bsws_h16ftq.xls", sheetName="企業規模計")
data15 <- read.xlsx("bsws_h15ftq.xls", sheetName="企業規模計")
data14 <- read.xlsx("bsws_h14ftq.xls", sheetName="企業規模計")
df <- data.frame(matrix(NA, nrow = 456, ncol=3))
df[,1] <- data16[,2]
df[,2] <- data15[,2]
df[,3] <- data14[,2]
rm(data16, data15, data14)
for (i in 1:3){
  k = i + 36
  ndf[k,1] <- 2005-i
  ndf[k,2] <- 0
  ndf[k,3] <- as.numeric(as.character(df[7,i]))
  ndf[k,4] <- as.numeric(as.character(df[38,i]))
  ndf[k,5] <- as.numeric(as.character(df[40,i]))
  ndf[k,6] <- as.numeric(as.character(df[42,i]))
  k = i + 36 + 3
  ndf[k,1] <- 2005-i
  ndf[k,2] <- 1
  ndf[k,3] <- as.numeric(as.character(df[48,i]))
  ndf[k,4] <- as.numeric(as.character(df[79,i]))
  ndf[k,5] <- as.numeric(as.character(df[81,i]))
  ndf[k,6] <- as.numeric(as.character(df[83,i]))
  k = i + 36 + 3 + 3
  ndf[k,1] <- 2005-i
  ndf[k,2] <- 2
  ndf[k,3] <- as.numeric(as.character(df[254,i]))
  ndf[k,4] <- as.numeric(as.character(df[285,i]))
  ndf[k,5] <- as.numeric(as.character(df[287,i]))
  ndf[k,6] <- as.numeric(as.character(df[289,i]))
}
rm(df)


data13 <- read.xlsx("bsws_h13ftq.xls", sheetName="企業規模計")
df <- data.frame(matrix(NA, nrow = 457, ncol=1))
df[,1] <- data13[,2]
rm(data13)
for (i in 1:1){
  k = i + 45
  ndf[k,1] <- 2002-i
  ndf[k,2] <- 0
  ndf[k,3] <- as.numeric(as.character(df[7,i]))
  ndf[k,4] <- as.numeric(as.character(df[38,i]))
  ndf[k,5] <- as.numeric(as.character(df[40,i]))
  ndf[k,6] <- as.numeric(as.character(df[42,i]))
  k = i + 45 + 1
  ndf[k,1] <- 2002-i
  ndf[k,2] <- 1
  ndf[k,3] <- as.numeric(as.character(df[49,i]))
  ndf[k,4] <- as.numeric(as.character(df[80,i]))
  ndf[k,5] <- as.numeric(as.character(df[82,i]))
  ndf[k,6] <- as.numeric(as.character(df[84,i]))
  k = i + 45 + 1 + 1
  ndf[k,1] <- 2002-i
  ndf[k,2] <- 2
  ndf[k,3] <- as.numeric(as.character(df[255,i]))
  ndf[k,4] <- as.numeric(as.character(df[286,i]))
  ndf[k,5] <- as.numeric(as.character(df[288,i]))
  ndf[k,6] <- as.numeric(as.character(df[290,i]))
}
rm(df)
ndf[,7] <- ndf[,6]/ndf[,4]
ndf[,8] <- ndf[,6]/ndf[,5]
ndf[,9] <- ndf[,5]/ndf[,4]
write.dta(ndf, "cd_fig8.dta")