rm(list = ls())
## load.fun(x) will load library 'x' if it is installed. If 'x' has
## not been installed, it will install it. Understanding this code is
## not necessary
## source: http://r.789695.n4.nabble.com/Install-package-automatically-if-not-there-tp2267532p2267659.html
load.fun <- function(x) {
  x <- as.character(substitute(x))
  if(isTRUE(x %in% .packages(all.available=TRUE))) {
    eval(parse(text=paste("require(", x, ")", sep="")))
  } else {
    #update.packages()  ## good idea, but may take some time. can
    ## usually be safely skipped
    eval(parse(text=paste("install.packages('", x, "')", sep="")))
    eval(parse(text=paste("require(", x, ")", sep="")))
  }
}
########################
load.fun(xlsx); load.fun(foreign); load.fun(stats) 


## Download datasets
setwd("/Users/mori/Dropbox/Research/KM_WoL/WoL_final/data/")
# BSWS 2016(h28) Regular Workers: Table 1
if (!file.exists("bsws_h28ft.xls")) {
  download.file(url="http://www.e-stat.go.jp/SG1/estat/Xlsdl.do?sinfid=000031226663",
                destfile="bsws_h28ft.xls")
}
# BSWS 2016(h28) Part-time Workers: Table 1
if (!file.exists("bsws_h28pt.xls")) {
  download.file(url="http://www.e-stat.go.jp/SG1/estat/Xlsdl.do?sinfid=000031228997",
                destfile="bsws_h28pt.xls")
}
if (!file.exists("bsws_h27ft.xls")) {
  download.file(url="http://www.e-stat.go.jp/SG1/estat/Xlsdl.do?sinfid=000028996409",
                destfile="bsws_h27ft.xls")
}
if (!file.exists("bsws_h27pt.xls")) {
  download.file(url="http://www.e-stat.go.jp/SG1/estat/Xlsdl.do?sinfid=000029008193",
                destfile="bsws_h27pt.xls")
}  
if (!file.exists("bsws_h26ft.xls")) {
  download.file(url="http://www.e-stat.go.jp/SG1/estat/Xlsdl.do?sinfid=000026308307",
                destfile="bsws_h26ft.xls")
}
if (!file.exists("bsws_h26pt.xls")) {
  download.file(url="http://www.e-stat.go.jp/SG1/estat/Xlsdl.do?sinfid=000026308750",
                destfile="bsws_h26pt.xls")
}
if (!file.exists("bsws_h25ft.xls")) {
  download.file(url="http://www.e-stat.go.jp/SG1/estat/Xlsdl.do?sinfid=000023602360",
                destfile="bsws_h25ft.xls")
}
if (!file.exists("bsws_h25pt.xls")) {
  download.file(url="http://www.e-stat.go.jp/SG1/estat/Xlsdl.do?sinfid=000023602761",
                destfile="bsws_h25pt.xls")
}
if (!file.exists("bsws_h24ft.xls")) {
  download.file(url="http://www.e-stat.go.jp/SG1/estat/Xlsdl.do?sinfid=000015981178",
                destfile="bsws_h24ft.xls")
}
if (!file.exists("bsws_h24pt.xls")) {
  download.file(url="http://www.e-stat.go.jp/SG1/estat/Xlsdl.do?sinfid=000016356610",
                destfile="bsws_h24pt.xls")
}
if (!file.exists("bsws_h23ft.xls")) {
  download.file(url="http://www.e-stat.go.jp/SG1/estat/Xlsdl.do?sinfid=000012740223",
                destfile="bsws_h23ft.xls")
}
if (!file.exists("bsws_h23pt.xls")) {
  download.file(url="http://www.e-stat.go.jp/SG1/estat/Xlsdl.do?sinfid=000012738575",
                destfile="bsws_h23pt.xls")
}
if (!file.exists("bsws_h22ft.xls")) {
  download.file(url="http://www.e-stat.go.jp/SG1/estat/Xlsdl.do?sinfid=000008278863",
                destfile="bsws_h22ft.xls")
}
if (!file.exists("bsws_h22pt.xls")) {
  download.file(url="http://www.e-stat.go.jp/SG1/estat/Xlsdl.do?sinfid=000008278750",
                destfile="bsws_h22pt.xls")
}
if (!file.exists("bsws_h21ft.xls")) {
  download.file(url="http://www.e-stat.go.jp/SG1/estat/Xlsdl.do?sinfid=000007214289",
                destfile="bsws_h21ft.xls")
}
if (!file.exists("bsws_h21pt.xls")) {
  download.file(url="http://www.e-stat.go.jp/SG1/estat/Xlsdl.do?sinfid=000007215233",
                destfile="bsws_h21pt.xls")
}
if (!file.exists("bsws_h20ft.xls")) {
  download.file(url="http://www.e-stat.go.jp/SG1/estat/Xlsdl.do?sinfid=000002950069",
                destfile="bsws_h20ft.xls")
}
if (!file.exists("bsws_h20pt.xls")) {
  download.file(url="http://www.e-stat.go.jp/SG1/estat/Xlsdl.do?sinfid=000002951148",
                destfile="bsws_h20pt.xls")
}
if (!file.exists("bsws_h19ft.xls")) {
  download.file(url="http://www.e-stat.go.jp/SG1/estat/Xlsdl.do?sinfid=000001254445",
                destfile="bsws_h19ft.xls")
}
if (!file.exists("bsws_h19pt.xls")) {
  download.file(url="http://www.e-stat.go.jp/SG1/estat/Xlsdl.do?sinfid=000001254547",
                destfile="bsws_h19pt.xls")
}
if (!file.exists("bsws_h18ft.xls")) {
  download.file(url="http://www.e-stat.go.jp/SG1/estat/Xlsdl.do?sinfid=000001183263",
                destfile="bsws_h18ft.xls")
}
if (!file.exists("bsws_h18pt.xls")) {
  download.file(url="http://www.e-stat.go.jp/SG1/estat/Xlsdl.do?sinfid=000001183377",
                destfile="bsws_h18pt.xls")
}
if (!file.exists("bsws_h17ft.xls")) {
  download.file(url="http://www.e-stat.go.jp/SG1/estat/Xlsdl.do?sinfid=000001256328",
                destfile="bsws_h17ft.xls")
}
if (!file.exists("bsws_h17pt.xls")) {
  download.file(url="http://www.e-stat.go.jp/SG1/estat/Xlsdl.do?sinfid=000001256435",
                destfile="bsws_h17pt.xls")
}
if (!file.exists("bsws_h16ft.xls")) {
  download.file(url="http://www.e-stat.go.jp/SG1/estat/Xlsdl.do?sinfid=000001256494",
                destfile="bsws_h16ft.xls")
}
if (!file.exists("bsws_h16pt.xls")) {
  download.file(url="http://www.e-stat.go.jp/SG1/estat/Xlsdl.do?sinfid=000001256601",
                destfile="bsws_h16pt.xls")
}
if (!file.exists("bsws_h15ft.xls")) {
  download.file(url="http://www.e-stat.go.jp/SG1/estat/Xlsdl.do?sinfid=000001256639",
                destfile="bsws_h15ft.xls")
}
if (!file.exists("bsws_h15pt.xls")) {
  download.file(url="http://www.e-stat.go.jp/SG1/estat/Xlsdl.do?sinfid=000001256722",
                destfile="bsws_h15pt.xls")
}
if (!file.exists("bsws_h14ft.xls")) {
  download.file(url="http://www.e-stat.go.jp/SG1/estat/Xlsdl.do?sinfid=000001256761",
                destfile="bsws_h14ft.xls")
}
if (!file.exists("bsws_h14pt.xls")) {
  download.file(url="http://www.e-stat.go.jp/SG1/estat/Xlsdl.do?sinfid=000001256844",
                destfile="bsws_h14pt.xls")
}
if (!file.exists("bsws_h13ft.xls")) {
  download.file(url="http://www.e-stat.go.jp/SG1/estat/Xlsdl.do?sinfid=000001256881",
                destfile="bsws_h13ft.xls")
}
if (!file.exists("bsws_h13pt.xls")) {
  download.file(url="http://www.e-stat.go.jp/SG1/estat/Xlsdl.do?sinfid=000001256963",
                destfile="bsws_h13pt.xls")
}
if (!file.exists("bsws_h12ft.xls")) {
  download.file(url="http://www.e-stat.go.jp/SG1/estat/Xlsdl.do?sinfid=000001256993",
                destfile="bsws_h12ft.xls")
}
if (!file.exists("bsws_h12ptm.xls")) {
  download.file(url="http://www.e-stat.go.jp/SG1/estat/Xlsdl.do?sinfid=000001257012",
                destfile="bsws_h12ptm.xls")
}
if (!file.exists("bsws_h12ptw.xls")) {
  download.file(url="http://www.e-stat.go.jp/SG1/estat/Xlsdl.do?sinfid=000001257013",
                destfile="bsws_h12ptw.xls")
}
## Read the datasets into dataframes
sdfm <- data.frame(matrix(NA, nrow = 17, ncol=5))
sdfw <- data.frame(matrix(NA, nrow = 17, ncol=5))
for (j in 1:17){
  k = 29-j
  infile  <- paste("bsws_h", k, sep="")
  infile1 <- paste(infile, "ft.xls", sep="")
  infile2 <- paste(infile, "pt.xls", sep="")
  if ((j>=1) && (j<=7)){
    dataf <- read.xlsx(infile1, sheetName="産業計")
    datap <- read.xlsx(infile2, sheetName="産業計～Ｒサービス業(他に分類されないもの)")
    dfm <- dataf[78:78,12:17]
    dfw <- dataf[143:143,12:17]
    dpm <- datap[24:24,13:17]
    dpw <- datap[37:37,13:17]
  }
  if (j==8){
    dataf <- read.xlsx(infile1, sheetName="T　産業計")
    datap <- read.xlsx(infile2, sheetName="産業計～ R サービス業")
    dfm <- dataf[78:78,12:17]
    dfw <- dataf[143:143,12:17]
    dpm <- datap[24:24,13:17]
    dpw <- datap[37:37,13:17]
  }
  if (j==9){
    dataf <- read.xlsx(infile1, sheetName="産業計")
    datap <- read.xlsx(infile2, sheetName="産業計～Ｑサービス業")
    dfm <- dataf[75:75,7:12]
    dfw <- dataf[141:141,7:12]
    dpm <- datap[21:21,6:10]
    dpw <- datap[34:34,6:10]
  }
  if (j==10){
    dataf <- read.xlsx(infile1, sheetName="産業計")
    datap <- read.xlsx(infile2, sheetName="産業計～Ｑサービス業")
    dfm <- dataf[75:75,7:12]
    dfw <- dataf[141:141,7:12]
    dpm <- datap[22:22,6:10]
    dpw <- datap[36:36,6:10]
  }
  if ((j>=11)&&(j<=12)){
    dataf <- read.xlsx(infile1, sheetName="産業計")
    datap <- read.xlsx(infile2, sheetName="産業計～Ｑサービス業")
    dfm <- dataf[22:22,7:12]
    dfw <- dataf[88:88,7:12]
    dpm <- datap[22:22,6:10]
    dpw <- datap[36:36,6:10]
  }
  if (j==13){
    dataf <- read.xlsx(infile1, sheetName="産業計")
    datap <- read.xlsx(infile2, sheetName="産業計､F製造業､J卸売･小売業､K金融･保険業")
    dfm <- dataf[24:24,4:9]
    dfw <- dataf[95:95,4:9]
    dpm <- datap[23:23,4:8]
    dpw <- datap[37:37,4:8]
  }
  if ( (j>=14) && (j<=16)){
    dataf <- read.xlsx(infile1, sheetName="産業計")
    datap <- read.xlsx(infile2, sheetName="産業計､F製造､I卸売小売､飲食店､J金融保険､Lｻｰﾋﾞｽ業")
    dfm <- dataf[24:24,4:9]
    dfw <- dataf[95:95,4:9]
    dpm <- datap[80:80,4:8]
    dpw <- datap[151:151,4:8]
  }
  if (j==17){
    dataf <- read.xlsx("bsws_h12ft.xls", sheetName="産業計")
    datapm <- read.xlsx("bsws_h12ptm.xls", sheetName="男性労働者")
    datapw <- read.xlsx("bsws_h12ptw.xls", sheetName="女性労働者")
    dfm <- dataf[24:24,4:9]
    dfw <- dataf[95:95,4:9]
    dpm <- datapm[9:9,4:8]
    dpw <- datapw[9:9,4:8]
  }
  df  <- data.frame(matrix(NA, nrow = 8, ncol=6))
  df1 <- data.frame(matrix(NA, nrow = 8, ncol=6))
  df2 <- data.frame(matrix(NA, nrow = 8, ncol=6))
  for (i in 1:6){
    df[,i] = as.character(dfm[,i])
    df[,i] = gsub(" ", "", df[,i]) 
    df1[,i] = as.numeric(df[,i])
    df[,i] = as.character(dfw[,i])
    df[,i] = gsub(" ", "", df[,i])   
    df2[,i] = as.numeric(df[,i])
  }
  df  <- data.frame(matrix(NA, nrow = 8, ncol=5))
  df3 <- data.frame(matrix(NA, nrow = 8, ncol=5))
  df4 <- data.frame(matrix(NA, nrow = 8, ncol=5))
  for (i in 1:5){
    df[,i] = as.character(dpm[,i])
    df[,i] = gsub(" ", "", df[,i]) 
    df3[,i] = as.numeric(df[,i])
    df[,i] = as.character(dpw[,i])
    df[,i] = gsub(" ", "", df[,i])   
    df4[,i] = as.numeric(df[,i])
  }
  rm(df, dataf, datap, datapm, datapw, dfm, dfw, dpm, dpw)
  ndf1 <- data.frame(matrix(NA, nrow = 1, ncol=6))
  ndf2 <- data.frame(matrix(NA, nrow = 1, ncol=6))
  ndf3 <- data.frame(matrix(NA, nrow = 1, ncol=6))
  ndf4 <- data.frame(matrix(NA, nrow = 1, ncol=6))
  ndf1[1:1,1] <- (df1[1:1,3] + df1[1:1,5]/12)*10   # monthly earnings for full-time men
  ndf2[1:1,1] <- (df2[1:1,3] + df2[1:1,5]/12)*10   # monthly earnings for full-time women
  ndf1[1:1,2] <- df1[1:1,1] + df1[1:1,2]    # monthly hours for full-time men
  ndf2[1:1,2] <- df2[1:1,1] + df2[1:1,2]    # monthly hours for full-time women
  ndf1[1:1,3] <- ndf1[1:1,1]/ndf1[1:1,2]    # hourly wages for men
  ndf2[1:1,3] <- ndf2[1:1,1]/ndf2[1:1,2]     # hourly wages for women
  ndf1[1:1,4] <- df1[1:1,6]    # size for full-time men
  ndf2[1:1,4] <- df2[1:1,6]    # size for full-time women
  ndf3[1:1,1] <- (df3[1:1,1]*df3[1:1,2])*12   # annual hours for part-time men
  ndf4[1:1,1] <- (df4[1:1,1]*df4[1:1,2])*12   # annual hours for part-time women
  ndf3[1:1,2] <- (df3[1:1,4]/ndf3[1:1,1])*10   # hourly bonus for part-time men
  ndf4[1:1,2] <- (df4[1:1,4]/ndf4[1:1,1])*10   # hourly bonus for part-time women
  ndf3[1:1,3] <- df3[1:1,3]/100 + ndf3[1:1,2]    # hourly wages for part-time men
  ndf4[1:1,3] <- df4[1:1,3]/100 + ndf4[1:1,2]    # hourly wages for part-time women
  ndf3[1:1,4] <- df3[1:1,5]    # size for part-time men
  ndf4[1:1,4] <- df4[1:1,5]    # size for part-time women
  rm(df1,df2,df3,df4)
  sdfm[j,1] <- ndf1[1,3]
  sdfm[j,2] <- ndf1[1,4]
  sdfm[j,3] <- ndf3[1,3]
  sdfm[j,4] <- ndf3[1,4]
  sdfw[j,1] <- ndf2[1,3]
  sdfw[j,2] <- ndf2[1,4]
  sdfw[j,3] <- ndf4[1,3]
  sdfw[j,4] <- ndf4[1,4]
  sdfm[j,5] <- 2017-j
  sdfw[j,5] <- 2017-j
  rm(ndf1,ndf2, ndf3, ndf4)
  print(2017-j)
}
names(sdfm)[names(sdfm)=="X1"] <- "mfw"
names(sdfw)[names(sdfw)=="X1"] <- "wfw"
names(sdfm)[names(sdfm)=="X2"] <- "mfs"
names(sdfw)[names(sdfw)=="X2"] <- "wfs"
names(sdfm)[names(sdfm)=="X3"] <- "mpw"
names(sdfw)[names(sdfw)=="X3"] <- "wpw"
names(sdfm)[names(sdfm)=="X4"] <- "mps"
names(sdfw)[names(sdfw)=="X4"] <- "wps"
names(sdfm)[names(sdfm)=="X5"] <- "year"
names(sdfw)[names(sdfw)=="X5"] <- "year"
sdfm <- sdfm[order(sdfm$year), ]
sdfw <- sdfw[order(sdfw$year), ]
write.dta(sdfm, "cd_fig0_mw.dta")
write.dta(sdfw, "cd_fig0_ww.dta")
##################
rm(sdfm, sdfw)
if (!file.exists("lfs_age_lf.xls")) {
  download.file(url="http://www.stat.go.jp/data/roudou/longtime/zuhyou/lt03-02.xls",
                destfile="lfs_age_lf.xls")
}
if (!file.exists("lfs_age_ue.xls")) {
  download.file(url="http://www.stat.go.jp/data/roudou/longtime/zuhyou/lt03-04.xls",
                destfile="lfs_age_ue.xls")
}

datalf <- read.xlsx("lfs_age_lf.xls", sheetName="総数")
dataue <- read.xlsx("lfs_age_ue.xls", sheetName="総数")
df <- data.frame(matrix(NA, nrow = 17, ncol=25))
ndf <- data.frame(matrix(NA, nrow = 17, ncol=25))
df[,1]    <- as.numeric(as.character(datalf[42:58,2]))
for (i in 1:12){
  k=i+2
  df[,i+1]    <- as.numeric(as.character(datalf[42:58,k]))
  df[,i+13] <- as.numeric(as.character(dataue[42:58,k]))
}
ndf = df
rm(df, datalf, dataue)
write.dta(ndf, "cd_fig0_lfs.dta")