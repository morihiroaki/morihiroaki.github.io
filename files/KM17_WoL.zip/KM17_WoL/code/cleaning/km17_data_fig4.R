rm(list = ls())
## load.fun(x) will load library 'x' if it is installed. If 'x' has
## not been installed, it will install it. Understanding this code is
## not necessary
## source: http://r.789695.n4.nabble.com/Install-package-automatically-if-not-there-tp2267532p2267659.html
load.fun <- function(x) {
  x <- as.character(substitute(x))
  if(isTRUE(x %in% .packages(all.available=TRUE))) {
    eval(parse(text=paste("require(", x, ")", sep="")))
  } else {
    #update.packages()  ## good idea, but may take some time. can
    ## usually be safely skipped
    eval(parse(text=paste("install.packages('", x, "')", sep="")))
    eval(parse(text=paste("require(", x, ")", sep="")))
  }
}
load.fun(xlsx); load.fun(foreign) 

setwd("/Users/mori/Dropbox/Research/KM_WoL/WoL_final/data")
if (!file.exists("lfs_inds.xls")) {
  download.file(url="https://www.e-stat.go.jp/SG1/estat/GL08020103.do?_xlsDownload_&fileId=000007931463&releaseCount=31",
                destfile="lfs_inds.xls")
}
dat <- read.xlsx("lfs_inds.xls", sheetIndex = 1)

ndf <- data.frame(matrix(NA, nrow = 11, ncol=3))
dfm <- data.frame(matrix(NA, nrow = 15, ncol=22))
dfw <- data.frame(matrix(NA, nrow = 15, ncol=22))
for (i in 1:21){
  km = i+23
  kw = i+23+21
  dfm[1:15,i] <-  as.numeric(as.character(dat[9:23,km]))
  dfw[1:15,i] <-  as.numeric(as.character(dat[9:23,kw]))
}
dfm[1:15,22] = dfm[1:15,3] - rowSums(dfm[1:15,4:21]) 
dfw[1:15,22] = dfw[1:15,3] - rowSums(dfw[1:15,4:21]) 
rm(dat)


ndf[1,1] = dfm[15,17] - dfm[1,17] # educ
ndf[1,2] = dfw[15,17] - dfw[1,17] # educ
ndf[2,1] = dfm[15,18] - dfm[1,18] # health
ndf[2,2] = dfw[15,18] - dfw[1,18] # health
ndf[3,1] = (dfm[15,15]+dfm[15,16]) - (dfm[1,15]+dfm[1,16]) # leisure
ndf[3,2] = (dfw[15,15]+dfw[15,16]) - (dfw[1,15]+dfw[1,16]) # leisure
ndf[4,1] = (dfm[15,14]+dfm[15,19]+dfm[15,20]+dfm[15,21]+dfm[15,22]) - (dfm[1,14]+dfm[1,19]+dfm[1,20]+dfm[1,21]+dfm[1,22]) # other services
ndf[4,2] = (dfw[15,14]+dfw[15,19]+dfw[15,20]+dfw[15,21]+dfw[15,22]) - (dfw[1,14]+dfw[1,19]+dfw[1,20]+dfw[1,21]+dfw[1,22]) # other services

ndf[5,1] = (dfm[15,12]+dfm[15,13]) - (dfm[1,12]+dfm[1,13]) # finance
ndf[5,2] = (dfw[15,12]+dfw[15,13]) - (dfw[1,12]+dfw[1,13]) 
ndf[6,1] = (dfm[15,9]) - (dfm[1,9]) # info
ndf[6,2] = (dfw[15,9]) - (dfw[1,9]) 
ndf[7,1] = (dfm[15,6]) - (dfm[1,6]) # const
ndf[7,2] = (dfw[15,6]) - (dfw[1,6]) 
ndf[8,1] = (dfm[15,7]) - (dfm[1,7]) # manufacturing
ndf[8,2] = (dfw[15,7]) - (dfw[1,7]) 
ndf[9,1] = (dfm[15,2]+dfm[15,4]+dfm[15,5]) - (dfm[1,2]+dfm[1,4]+dfm[1,5]) # natural
ndf[9,2] = (dfw[15,2]+dfw[15,4]+dfw[15,5]) - (dfw[1,2]+dfw[1,4]+dfw[1,5]) 
ndf[10,1] = (dfm[15,8]+dfm[15,10]+dfm[15,11]) - (dfm[1,8]+dfm[1,10]+dfm[1,11]) # trade
ndf[10,2] = (dfw[15,8]+dfw[15,10]+dfw[15,11]) - (dfw[1,8]+dfw[1,10]+dfw[1,11]) 
ndf[11,1:2] = colSums(ndf[1:10,1:2])
ndf[1,3] = "01. Educational services"
ndf[2,3] = "03. Healthcare services"
ndf[3,3] = "02. Leisure and food services"
ndf[4,3] = "04. Other services"
ndf[5,3] = "05. Financial activities"
ndf[6,3] = "06. Information and communications"
ndf[7,3] = "07. Construction"
ndf[8,3] = "08. Manufacturing"
ndf[9,3] = "09. Natural resources and mining"
ndf[10,3] = "10. Trade, transportation, and utilities"
ndf[11,3] = "Total"

write.dta(ndf, "cd_fig4.dta")