rm(list = ls())
## load.fun(x) will load library 'x' if it is installed. If 'x' has
## not been installed, it will install it. Understanding this code is
## not necessary
## source: http://r.789695.n4.nabble.com/Install-package-automatically-if-not-there-tp2267532p2267659.html
load.fun <- function(x) {
  x <- as.character(substitute(x))
  if(isTRUE(x %in% .packages(all.available=TRUE))) {
    eval(parse(text=paste("require(", x, ")", sep="")))
  } else {
    #update.packages()  ## good idea, but may take some time. can
    ## usually be safely skipped
    eval(parse(text=paste("install.packages('", x, "')", sep="")))
    eval(parse(text=paste("require(", x, ")", sep="")))
  }
}
load.fun(xlsx); load.fun(foreign) 
# Specify a working directory
setwd("")
if (!file.exists("lfs_age_pop.xls")) {
  download.file(url="http://www.stat.go.jp/data/roudou/longtime/zuhyou/lt03-01.xls",
                destfile="lfs_age_pop.xls")
}
if (!file.exists("lfs_age_lf.xls")) {
  download.file(url="http://www.stat.go.jp/data/roudou/longtime/zuhyou/lt03-02.xls",
                destfile="lfs_age_lf.xls")
}
ndf <- data.frame(matrix(NA, nrow = 17, ncol=5))
datap <- read.xlsx("lfs_age_pop.xls", sheetName="男")
datal <- read.xlsx("lfs_age_lf.xls", sheetName="男")
df <- data.frame(matrix(NA, nrow = 17, ncol=24))
for (i in 1:12){
  k=i+2
  df[,i]      <- as.numeric(as.character(datap[42:58,k]))
  df[,i+12]   <- as.numeric(as.character(datal[42:58,k]))
}
tdf <- data.frame(matrix(NA, nrow = 17, ncol=2))
ndf[,1] = as.numeric(as.character(datal[42:58,2]))
tdf[,1] = as.data.frame(rowSums(df[,4:9]))
tdf[,2] = as.data.frame(rowSums(df[,16:21]))
ndf[,2] = tdf[,2]/tdf[,1]
names(ndf)[names(ndf)=="X1"] <- "year"
names(ndf)[names(ndf)=="X2"] <- "lmjp"
rm(df, datal, datap, tdf)
datap <- read.xlsx("lfs_age_pop.xls", sheetName="女")
datal <- read.xlsx("lfs_age_lf.xls", sheetName="女")
df <- data.frame(matrix(NA, nrow = 17, ncol=24))
for (i in 1:12){
  k=i+2
  df[,i]      <- as.numeric(as.character(datap[42:58,k]))
  df[,i+12]   <- as.numeric(as.character(datal[42:58,k]))
}
tdf <- data.frame(matrix(NA, nrow = 17, ncol=2))
tdf[,1] = as.data.frame(rowSums(df[,4:9]))
tdf[,2] = as.data.frame(rowSums(df[,16:21]))
ndf[,3] = tdf[,2]/tdf[,1]
names(ndf)[names(ndf)=="X3"] <- "lwjp"
rm(df, datal, datap, tdf)
dataus <- read.xlsx("cps_pm.xlsx", sheetName="Sheet1")
ndf[,4] <- dataus[,3]
ndf[,5] <- dataus[,2]
names(ndf)[names(ndf)=="X4"] <- "lmus"
names(ndf)[names(ndf)=="X5"] <- "lwus"
rm(dataus)
write.dta(ndf, "cd_fig2.dta")