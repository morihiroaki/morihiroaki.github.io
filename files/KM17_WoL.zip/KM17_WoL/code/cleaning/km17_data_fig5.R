 rm(list = ls())
## load.fun(x) will load library 'x' if it is installed. If 'x' has
## not been installed, it will install it. Understanding this code is
## not necessary
## source: http://r.789695.n4.nabble.com/Install-package-automatically-if-not-there-tp2267532p2267659.html
load.fun <- function(x) {
  x <- as.character(substitute(x))
  if(isTRUE(x %in% .packages(all.available=TRUE))) {
    eval(parse(text=paste("require(", x, ")", sep="")))
  } else {
    #update.packages()  ## good idea, but may take some time. can
    ## usually be safely skipped
    eval(parse(text=paste("install.packages('", x, "')", sep="")))
    eval(parse(text=paste("require(", x, ")", sep="")))
  }
}
########################
load.fun(xlsx); load.fun(foreign); load.fun(stats) 

## Download datasets
# Specify a working directory
setwd("")
if (!file.exists("lfs_age_lf.xls")) {
  download.file(url="http://www.stat.go.jp/data/roudou/longtime/zuhyou/lt03-02.xls",
                destfile="lfs_age_lf.xls")
}
if (!file.exists("lfs_age_ue.xls")) {
  download.file(url="http://www.stat.go.jp/data/roudou/longtime/zuhyou/lt03-04.xls",
                destfile="lfs_age_ue.xls")
}

dlfm <- read.xlsx("lfs_age_lf.xls", sheetName="男")
duem <- read.xlsx("lfs_age_ue.xls", sheetName="男")
dlfw <- read.xlsx("lfs_age_lf.xls", sheetName="女")
duew <- read.xlsx("lfs_age_ue.xls", sheetName="女")

ndfm <- data.frame(matrix(NA, nrow = 17, ncol=25))
ndfw <- data.frame(matrix(NA, nrow = 17, ncol=25))

ndfm[,1]    <- as.numeric(as.character(dlfm[42:58,2]))
ndfw[,1]    <- as.numeric(as.character(dlfw[42:58,2]))

for (i in 1:12){
  k=i+2
  ndfm[,i+1]  <- as.numeric(as.character(dlfm[42:58,k]))
  ndfm[,i+13] <- as.numeric(as.character(duem[42:58,k]))
  ndfw[,i+1]  <- as.numeric(as.character(dlfw[42:58,k]))
  ndfw[,i+13] <- as.numeric(as.character(duew[42:58,k]))
}
write.dta(ndfm, "cd_fig5_mu.dta")
write.dta(ndfw, "cd_fig5_wu.dta")
rm(dlfm, dlfw, duem, duew)